public class Exercici6 {
    public static void main(String[] args) {
    }

    public void throwException() {
//        throw new ExcepcioCustom("");
        // L'IDE diu que m'he d'encarregar de la excepcio.
    }
}

