package Containers2.Exercici1;

public class Main {
    public static void main(String[] args) {
        Sequence s = new Sequence();
        for (Integer i : s) {
            System.out.println(i);
        }
    }
}
