public class Exercici_1 {
    public static void main(String[] args) {
        /*
        1. Alguns programes empren «int a[]» enlloc de «int[] a», quina és la diferència?.
            En principi, no hi ha diferència entre els dos.");
        2. Per què els índexs en els arrays comencen en 0 i no en 1?
            Per que la primera posició es la 0, ja que a informatica es comença a comptar a partir de 0.
        3. Què passa si emprem un número negatiu per indexar un array?"
            Torna error.
        4. Si «a[]» és un array, per què quan executem «System.out.println(a)» surt un número en hexadecimal, com @f432321?
            Perque ens torna la referència a l'objecte, no el valor de l'objecte.
        5. Si creem un array d'enters de 100 posicions, quin valor tindrà cada element, inicialment?
            0
         */

    }
}
