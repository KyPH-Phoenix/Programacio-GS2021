public class Exercici_5 {
    public static void main(String[] args) {
        //int[] a;
        //for (int i = 0; i < 10; i++) {
        //    a[i] = i * i;
        //}

        // El codi anterior no funciona perque l'array no es declara a cap moment.
    }
}
