import java.lang.reflect.Array;
import java.util.Arrays;

public class Exercici_2 {
    public static void main(String[] args) {
        int[] ar = new int[1000];

        //System.out.println(ar[1000]);

        //Si s'intenta accedir a l'element numero 1000 no es pot perque no existeix, per tant torna error.
    }
}
