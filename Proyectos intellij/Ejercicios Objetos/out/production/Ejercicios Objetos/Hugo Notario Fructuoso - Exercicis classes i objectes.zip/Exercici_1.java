public class Exercici_1 {
    public static void main(String[] args) {
        QuadratMagic quadrat1 = new QuadratMagic(5);
        QuadratMagic quadrat2 = new QuadratMagic(7);

        System.out.println();
        quadrat1.imprimeix();
        System.out.println();
        quadrat2.imprimeix();
    }
}
