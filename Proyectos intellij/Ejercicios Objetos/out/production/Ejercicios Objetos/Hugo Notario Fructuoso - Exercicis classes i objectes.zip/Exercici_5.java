public class Exercici_5 {
    /*
    Totes les preguntes son amb referencia a la classe "Parts".

        class Parts {
            public static int x = 7;
            public int y = 3;
        }

    a) Quina és la variable de classe?
        - La variable de classe es "x".
    b) Quina és la variable d'instància (membre)?
        - La variable d'instancia es "y".
    c) Qué mostra el següent codi?

        Parts a = new Parts();
        Parts b = new Parts();
        a.y = 5; b.y = 6;
        a.x = 1; b.x = 2;
        System.out.println(a.y);
        Sytem.out.println(b.y);
        System.out.println(a.x);
        System.out.println(b.x);

        - Aquest codi toca imprimir per pantalla:
            5
            6
            2
            2
     */
}

