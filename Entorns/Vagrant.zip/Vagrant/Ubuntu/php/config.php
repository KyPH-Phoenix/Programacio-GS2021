<?php

define("MYSQL_USER", "admin");
define("MYSQL_PASSWORD", "esliceu");
define("MYSQL_HOST", "localhost");
define("MYSQL_DATABASE", "entorns");
